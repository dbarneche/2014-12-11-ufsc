
library(plyr)
data <- read.csv("data/gapminder-FiveYearData.csv", stringsAsFactors=FALSE)

