data <- read.csv("gapminder-FiveYearData.csv", stringsAsFactors=FALSE)
